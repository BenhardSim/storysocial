package com.example.storiessocial.injection

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.preferencesDataStore
import com.example.storiessocial.model.AppRespository
import com.example.storiessocial.model.local.UserPreference

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "settings")

object Injection {
    fun provideRepository(context: Context): AppRespository {
        val pref = UserPreference.getInstance(context.dataStore)
        return AppRespository.getInstance(pref)
    }

    fun providePreferences(context: Context) : UserPreference {
        return UserPreference.getInstance(context.dataStore)
    }
}