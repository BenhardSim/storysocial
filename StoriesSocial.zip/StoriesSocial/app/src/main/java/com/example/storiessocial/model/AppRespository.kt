package com.example.storiessocial.model

import androidx.lifecycle.*
import com.example.storiessocial.model.local.UserModel
import com.example.storiessocial.model.local.UserPreference
import com.example.storiessocial.model.remote.response.AddStoryResponse
import com.example.storiessocial.model.remote.response.LoginResponse
import com.example.storiessocial.model.remote.response.RegisterResponse
import com.example.storiessocial.model.remote.response.StoriesResponse
import com.example.storiessocial.model.remote.retrofit.APIConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import okhttp3.MultipartBody
import okhttp3.RequestBody
import kotlin.Result

class AppRespository(
    private val pref : UserPreference,
) {

    suspend fun login(email: String, password: String): Flow<Result<LoginResponse>> = flow {
        try{
            val response = APIConfig.getApiService().userLogin(email, password)
            emit(Result.success(response))
        }catch(e: Exception) {
            emit(Result.failure(e))
        }
    }.flowOn(Dispatchers.IO)

    suspend fun register(name: String, email: String, password: String): Flow<Result<RegisterResponse>> = flow {
        try{
            val response = APIConfig.getApiService().userRegister(name,email,password)
            emit(Result.success(response))
        }catch(e: Exception) {
            emit(Result.failure(e))
        }
    }.flowOn(Dispatchers.IO)

    suspend fun saveUser(user: UserModel) {
        pref.saveUser(user)
    }

    suspend fun postStoryResponse(token: String, file: MultipartBody.Part, desc: RequestBody, lon: Float, lat: Float): AddStoryResponse{
        return APIConfig.getApiService().addStories(token,file,desc,lat,lon)
    }

    suspend fun getAllStories(token: String): StoriesResponse{
        return APIConfig.getApiService().allStories(token)
    }

    fun getToken(): LiveData<UserModel> {
        return pref.getToken().asLiveData()
    }

    companion object {
        @Volatile
        private var instance: AppRespository? = null
        fun getInstance(
            pref : UserPreference
        ): AppRespository =
            instance ?: synchronized(this) {
                instance ?: AppRespository(pref)
            }.also { instance = it }
    }

}