package com.example.storiessocial.view.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.storiessocial.R
import java.text.ParseException
import java.text.SimpleDateFormat
import java.util.*

class StoriesAdapter(private val listStories: List<MutableMap<String,String>>) : RecyclerView.Adapter<StoriesAdapter.ViewHolder>() {

    private lateinit var onItemClickCallback: OnItemClickCallback

    interface OnItemClickCallback {
        fun onItemClicked(username: MutableMap<String,String>)
    }

    fun setOnItemClickCallback(onItemClickCallback: OnItemClickCallback) {
        this.onItemClickCallback = onItemClickCallback
    }

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val storyItem : ImageView = view.findViewById(R.id.img_item_photo)
        val usernameItem : TextView = view.findViewById(R.id.tv_item_name)
        val date: TextView = view.findViewById(R.id.date)
    }

    override fun onCreateViewHolder(viewGroup: ViewGroup, viewType: Int) =
        ViewHolder(LayoutInflater.from(viewGroup.context).inflate(R.layout.item_stories, viewGroup, false))


    override fun onBindViewHolder(viewHolder: ViewHolder, position: Int) {
        val photoUrl = listStories[position]["photoUrl"]
        val name = listStories[position]["name"]
        val createdAT = listStories[position]["createdAt"]

        Glide.with(viewHolder.itemView.context).load(photoUrl).centerCrop().into(viewHolder.storyItem)
        viewHolder.usernameItem.text = name

        val inputFormatStr = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"
        val outputFormatStr = "dd-MM-yyyy HH:mm:ss"

        val inputFormat = SimpleDateFormat(inputFormatStr, Locale.getDefault())
        val outputFormat = SimpleDateFormat(outputFormatStr, Locale.getDefault())

        try {
            val date = createdAT?.let { inputFormat.parse(it) }
            val outputDateStr = date?.let { outputFormat.format(it) }
            viewHolder.date.text = outputDateStr
        } catch (e: ParseException) {
            e.printStackTrace()
        }

        viewHolder.itemView.setOnClickListener{
            if (name != null) {
                onItemClickCallback.onItemClicked(listStories[position])
            }
        }

    }

    override fun getItemCount() = listStories.size


}