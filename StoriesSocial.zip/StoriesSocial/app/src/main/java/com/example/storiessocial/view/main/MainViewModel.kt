package com.example.storiessocial.view.main

import android.util.Log
import androidx.lifecycle.*
import com.example.storiessocial.model.AppRespository
import com.example.storiessocial.model.local.UserModel
import com.example.storiessocial.model.local.UserPreference
import com.example.storiessocial.model.remote.response.StoriesResponse
import kotlinx.coroutines.launch


class MainViewModel(private val pref: UserPreference, private val appRepo: AppRespository) : ViewModel() {

    fun getUser(): LiveData<UserModel> {
        return pref.getUser().asLiveData()
    }

    fun getToken(): LiveData<UserModel> {
        return appRepo.getToken()
    }
    private val allStoriesLiveData = MutableLiveData<com.example.storiessocial.model.Result<StoriesResponse>>()

    fun allStories(token: String): LiveData<com.example.storiessocial.model.Result<StoriesResponse>> {
        viewModelScope.launch {
            allStoriesLiveData.value = com.example.storiessocial.model.Result.Loading
            try{
                val bearerToken = "Bearer $token"
                val response = appRepo.getAllStories(bearerToken)
                allStoriesLiveData.value = com.example.storiessocial.model.Result.Success(response)
            }catch(e: Exception) {
                Log.e("viewmodel",e.toString())
            }
        }
        return allStoriesLiveData
    }

    fun logout() {
        viewModelScope.launch {
            pref.logout()
        }
    }

}